# By < @coder_debojit >
# // @debojit_update
#dont remove credit else gay

from .. import Debojit
from telethon import events, Button

@Debojit.on(events.NewMessage(incoming=True, pattern="/start"))
async def start(event):
    await event.reply("**Hello It Made By @coder_debojit!**",
                   buttons = [
    [
        Button.url("📡Updates", url="https://t.me/debojit_update"),
        Button.url("ꜱᴜᴘᴘᴏʀᴛ", url="https://t.me/royel_coding_support"),
    ],
    [Button.inline("ʜᴇʟᴘ❔", data="help_back")]
    ])

@Debojit.on(events.callbackquery.CallbackQuery(data="help_back"))
async def ex(event):
    await event.edit("**Here is commands**",
                      buttons=[
                     [Button.inline("        ✘Like✘        ", data="bsdk")]                     
                     ])

@Debojit.on(events.callbackquery.CallbackQuery(data="bsdk"))
async def ex(event):
    await event.edit("**Add here anything**",
                     buttons=[
                        [Button.inline("✘Back!✘", data="help_back")]
                         ])
