# By < @coder_debojit >
# // @debojit_update
#dont remove credit else gay

import glob
from pathlib import Path
import logging
from Debojit.utils import load_plugins
from . import Debojit

logging.basicConfig(format='[%(levelname) 5s/%(asctime)s] %(name)s: %(message)s',
                    level=logging.WARNING)

path = "Debojit/plugins/*.py"
files = glob.glob(path)
for name in files:
    with open(name) as a:
        patt = Path(a.name)
        plugin_name = patt.stem
        load_plugins(plugin_name.replace(".py", ""))

print("Successfully deployed!")
print("Enjoy! Do visit @debojit_update")

if __name__ == "__main__":
    Debojit.run_until_disconnected()
