# Telegram Bot
Simple base used to make a Telegram Bot in [telethon](https://github.com/LonamiWebs/Telethon).
   
Join [✘ Updates ✘](https://t.me/https://t.me/debojit_update)!
    
Note: The `client`, here, is named `Debojit`.
   
# Deploy It
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
